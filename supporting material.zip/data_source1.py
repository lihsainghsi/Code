import matplotlib.pyplot as plt
import networkx
from numpy import *
import random
import torch

N = 10000
K = 4
edg = 0.5
p1 = 0.1  # WS small world model parameters
p2 = 0.2  # omega node ratio
p3 = 0.001
seed = 1

yita = 100
betaU = 0.2  # U S-I
temp = 0.04
betaA = betaU * temp  # A S-I
miu = 0.06  # I-R
delta = 0.04  # A-U
gam = 0.04  # U-A

A = []
U = []
S = []
I = []
R = []

G_i = networkx.barabasi_albert_graph(N, 4, seed)  # Information Network
G = networkx.watts_strogatz_graph(N, K, p1, seed)  # Contact Network


def delete(G, num):
    if num == 0:  # Remove from large by degrees
        remo = []
        large = sorted(G.degree(), key=lambda x: x[1], reverse=True)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 1:  # Removal by degrees from small
        remo = []
        large = sorted(G.degree(), key=lambda x: x[1], reverse=False)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 2:  # Random removal
        remo = random.sample(list(G.nodes), int(N * p2))
        G.remove_nodes_from(remo)
    if num == 3:  # Removal by large median centrality
        remo = []
        large = sorted(networkx.betweenness_centrality(G_i).items(), key=lambda x: x[1], reverse=True)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 4:  # Removal by median centrality of small
        remo = []
        large = sorted(networkx.betweenness_centrality(G_i).items(), key=lambda x: x[1], reverse=False)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    return G


def init(G_i, G):
    for i in G.nodes:
        G.nodes[i]["state"] = 0  # 0 for susceptible state 1 for infected state 2 for recovered state
    for i in G_i.nodes:
        G_i.nodes[i]["state"] = 0  # 0 for unconscious state 1 for conscious state
    Iinit = random.sample(list(G.nodes), int(N * p3))
    for i in range(N):  # Initialize the infected node and set its corresponding awareness layer to known
        if i in Iinit:
            G.nodes[i]["state"] = 1
        if i in G_i.nodes and i in Iinit:
            G_i.nodes[i]["state"] = 1
    return G_i, G


def iter(n):
    global G_i, G
    global A, U, S, I, R
    for i in range(n):
        countA = 0
        countU = 0
        countS = 0
        countI = 0
        countR = 0
        for i in G.nodes:
            if G.nodes[i]["state"] == 0:
                countS += 1
            elif G.nodes[i]["state"] == 1:
                countI += 1
            elif G.nodes[i]["state"] == 2:
                countR += 1
        S.append(countS)
        I.append(countI)
        R.append(countR)
        for i in G_i.nodes:
            if G_i.nodes[i]["state"] == 0:
                countU += 1
            elif G_i.nodes[i]["state"] == 1:
                countA += 1
        U.append(countU)
        A.append(countA)
        for q in G_i.nodes:
            temp = 0
            for k in networkx.neighbors(G_i,
                                        q):  # Count the number of people in their neighborhood who are in the conscious state
                if G_i.nodes[k]["state"] == 1:
                    temp += 1
            if G_i.nodes[q]["state"] == 0:
                if random.random() < 1 - pow(1 - gam, temp):
                    G_i.nodes[q]["state"] = 1
            elif G_i.nodes[q]["state"] == 1:
                if random.random() < delta:
                    G_i.nodes[q]["state"] = 0
        for j in G.nodes:
            if G.nodes[j]["state"] == 1:
                if j in G_i.nodes:
                    if G_i.nodes[j]["state"] == 0:
                        G_i.nodes[j]["state"] = 1
            temp = 0
            for k in networkx.neighbors(G, j):
                if G.nodes[k]["state"] == 1:
                    temp = temp + 1
            if G.nodes[j]["state"] == 0:
                if j in G_i.nodes:
                    if G_i.nodes[j]["state"] == 0:
                        if random.random() < (1 - pow(1 - betaU, temp)):
                            G.nodes[j]["state"] = 1
                    elif G_i.nodes[j]["state"] == 1:
                        if random.random() < (1 - pow(1 - betaA, temp)):
                            G.nodes[j]["state"] = 0
                elif j not in G_i.nodes:
                    if random.random() < (1 - pow(1 - betaU, temp)):
                        G.nodes[j]["state"] = 1
            elif G.nodes[j]["state"] == 1:
                if j in G_i.nodes:
                    if G_i.nodes[j]["state"] == 0:
                        G_i.nodes[j]["state"] = 1
                if random.random() < miu:
                    G.nodes[j]["state"] = 2


def clear():
    global A, U, S, I, R, G_i, G
    G_i = networkx.barabasi_albert_graph(N, K, seed)
    G = networkx.watts_strogatz_graph(N, K, p1, seed)
    A = []
    U = []
    S = []
    I = []
    R = []


# Please customize the number of iterations

get_I1 = []
for i in range(11):
    betaU = 1 - i / 10
    temp2 = []

    for j in range(11):
        gam = j / 10
        G_i = delete(G_i, 0)  # Please customize the way you delete nodes
        G_i, G = init(G_i, G)
        iter(400)
        a = R[-1]
        temp2.append(a)
        clear()
    get_I1.append(temp2)

# Please customize the format of the data output