import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
test = []
data = test # Please customize the data input

plt.figure()
plt.gcf().subplots_adjust(bottom=0.2)
plt.imshow(data, cmap=plt.cm.jet,interpolation="gaussian",vmin=0,vmax=1,extent=(0.0,1.0,0.0,1.0))
plt.tick_params(axis='both',color = 'black',direction = 'out')
plt.xticks(np.arange(0,1.1,step = 0.1))
plt.yticks(np.arange(0,1.1,step = 0.1))
plt.xlabel(chr(955),fontsize = 23)
plt.ylabel(chr(946),fontsize = 23)

plt.colorbar()
plt.savefig('your file', dpi = 600)
plt.show()
