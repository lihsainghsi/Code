import numpy as np
import matplotlib.pyplot as plt

# 1
x = [x for x in range(11)]
# The following is the test data, please enter your real data
y0 = [0.0023, 0.0029, 0.0049, 0.0164, 0.0355, 0.1719, 0.5417, 0.7777, 0.9077, 0.9672, 0.9941]
y1 = np.array([18,22,91,729,1656,3619,4959,6643,7762,8939,9920])
y2 = np.array([20,219,1341,4576,7274,8907,9531,9945,9936,9897,9924])
y3 = np.array([30,381,365,3124,6226,8302,9244,9766,9897,9929,9932])
y4 = np.array([30,24,69,132,169,3842,5216,6649,7931,8936,9892])
y1 = y1/10000
y2 = y2/10000
y3 = y3/10000
y4 = y4/10000

# label在图示(legend)中显示。若为数学公式,则最好在字符串前后添加"$"符号
# color：b:blue、g:green、r:red、c:cyan、m:magenta、y:yellow、k:black、w:white、、、
# 线型：-  --   -.  :    ,
# marker：.  ,   o   v    <    *    +    1
plt.figure(figsize=(10,7.5))
# plt.grid(linestyle="--")  # 设置背景网格线为虚线
ax = plt.gca()
# ax.spines['top'].set_visible(False)  # 去掉上边框
# ax.spines['right'].set_visible(False)  # 去掉右边框

plt.plot(x, y0,marker = 'o',color = 'k',linestyle ='--', label=r"Random", linewidth=1.5)
plt.plot(x, y2,marker = '^',color = 'red', label=r"High degree nodes ", linewidth=1.5)
plt.plot(x, y1,marker = 's',color = 'b', label=r'Low degree nodes', linewidth=1.5)




group_labels = ['0%', '10%', '20%', '30%', '40%', '50%', '60%', '70%', '80%' ,' 90%','100%']
plt.xticks(x, group_labels, fontsize=10)
# plt.yticks(fontsize=12, fontweight='bold')
# plt.title("example", fontsize=12, fontweight='bold')
plt.xlabel(r"The ratio of $\Omega$ nodes", fontsize = 33)
plt.ylabel(r"$\rho^R$", fontsize=33, fontweight='bold')
plt.xlim(0, 10)
plt.ylim(0, 1)

plt.legend()
plt.legend(loc=0, numpoints=1,frameon = False)
plt.xticks(size = 15, weight ='bold')
plt.yticks(size = 15, weight ='bold')
leg = plt.gca().get_legend()
ltext = leg.get_texts()
plt.setp(ltext, fontsize=20)

plt.savefig('your file', dpi = 600)
plt.show()
