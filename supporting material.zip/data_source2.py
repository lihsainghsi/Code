import matplotlib.pyplot as plt
import networkx
from numpy import *
import random

N = 10000
K = 4
edg = 0.5
p1 = 0.1
p2 = 0.2
p3 = 0.001
seed = 1

yita = 100
betaU = 0.5  # U S-I
temp = 0.04
betaA = betaU * temp  # A S-I
miu = 0.06  # I-R
delta = 0.04  # A-U
gam = 0.5  # U-A

A = []
U = []
S = []
I = []
R = []

G_i = networkx.barabasi_albert_graph(N, 4, seed)
G = networkx.watts_strogatz_graph(N, K, p1, seed)


def delete(G, num):
    if num == 0:
        remo = []
        large = sorted(G.degree(), key=lambda x: x[1], reverse=True)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 1:
        remo = []
        large = sorted(G.degree(), key=lambda x: x[1], reverse=False)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 2:
        remo = random.sample(list(G.nodes), int(N * p2))
        G.remove_nodes_from(remo)
    if num == 3:
        remo = []
        large = sorted(networkx.betweenness_centrality(G_i).items(), key=lambda x: x[1], reverse=True)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 4:
        remo = []
        large = sorted(networkx.betweenness_centrality(G_i).items(), key=lambda x: x[1], reverse=False)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    if num == 5:
        remo = []
        large = sorted(networkx.clustering(G_i).items(), key=lambda x: x[1], reverse=True)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)

    if num == 6:
        remo = []
        large = sorted(networkx.clustering(G_i).items(), key=lambda x: x[1], reverse=False)
        for i in range(int(N * p2)):
            remo.append(large[i][0])
        G.remove_nodes_from(remo)
    return G


def init(G_i, G):
    for i in G.nodes:
        G.nodes[i]["state"] = 0
    for i in G_i.nodes:
        G_i.nodes[i]["state"] = 0
    Iinit = random.sample(list(G.nodes), int(N * p3))
    for i in range(N):
        if i in Iinit:
            G.nodes[i]["state"] = 1
        if i in G_i.nodes and i in Iinit:
            G_i.nodes[i]["state"] = 1
    return G_i, G


def iter(n):
    global G_i, G
    global A, U, S, I, R
    for i in range(n):
        countA = 0
        countU = 0
        countS = 0
        countI = 0
        countR = 0
        for i in G.nodes:
            if G.nodes[i]["state"] == 0:
                countS += 1
            elif G.nodes[i]["state"] == 1:
                countI += 1
            elif G.nodes[i]["state"] == 2:
                countR += 1
        S.append(countS)
        I.append(countI)
        R.append(countR)
        for i in G_i.nodes:
            if G_i.nodes[i]["state"] == 0:
                countU += 1
            elif G_i.nodes[i]["state"] == 1:
                countA += 1
        U.append(countU)
        A.append(countA)
        for q in G_i.nodes:
            temp = 0
            for k in networkx.neighbors(G_i, q):
                if G_i.nodes[k]["state"] == 1:
                    temp += 1
            if G_i.nodes[q]["state"] == 0:
                if random.random() < 1 - pow(1 - gam, temp):
                    G_i.nodes[q]["state"] = 1
            elif G_i.nodes[q]["state"] == 1:
                if random.random() < delta:
                    G_i.nodes[q]["state"] = 0
        for j in G.nodes:
            if G.nodes[j]["state"] == 1:
                if j in G_i.nodes:
                    if G_i.nodes[j]["state"] == 0:
                        G_i.nodes[j]["state"] = 1
            temp = 0
            for k in networkx.neighbors(G, j):
                if G.nodes[k]["state"] == 1:
                    temp = temp + 1
            if G.nodes[j]["state"] == 0:
                if j in G_i.nodes:
                    if G_i.nodes[j]["state"] == 0:
                        if random.random() < (1 - pow(1 - betaU, temp)):
                            G.nodes[j]["state"] = 1
                    elif G_i.nodes[j]["state"] == 1:
                        if random.random() < (1 - pow(1 - betaA, temp)):
                            G.nodes[j]["state"] = 0
                elif j not in G_i.nodes:
                    if random.random() < (1 - pow(1 - betaU, temp)):
                        G.nodes[j]["state"] = 1
            elif G.nodes[j]["state"] == 1:
                if j in G_i.nodes:
                    if G_i.nodes[j]["state"] == 0:
                        G_i.nodes[j]["state"] = 1
                if random.random() < miu:
                    G.nodes[j]["state"] = 2


def clear():
    global A, U, S, I, R, G_i, G
    G_i = networkx.barabasi_albert_graph(N, K, seed)
    G = networkx.watts_strogatz_graph(N, K, p1, seed)
    A = []
    U = []
    S = []
    I = []
    R = []


# Please customize the number of iterations
for i in [0.2, 0.5, 0.8]:
    temp = []
    G_i = delete(G_i, 1)
    G_i, G = init(G_i, G)
    gam = i
    iter(4)
    clear()

#Please customize the data output

